Fake Name Generator
http://www.fakenamegenerator.com/

-------------------------------------------------------------------------------

Thanks for ordering from the Fake Name Generator! If you run into any problems,
please contact Jacob@FakeNameGenerator.com.

To place a FREE order, visit http://www.fakenamegenerator.com/

-------------------------------------------------------------------------------

COPYRIGHT AND DISTRIBUTION

Fake Name Generator identities are copyright 2012 Corban Works, LLC.

Fake Name Generator identities are dual-licensed under the GPLv3 and Creative
Commons Attribution-Share Alike 3.0 United States licenses. You may choose
either license, but are bound to the terms of the license you choose. You may
not use the Fake Name Generator identities without choosing a license.

For full license details, please visit:
http://www.fakenamegenerator.com/license.php

-------------------------------------------------------------------------------

Frequently Asked Questions

Q: Isn't this illegal?
A: I really don't see how it could be. If I ask you to make up a random name
   and address, is it illegal if you do?

Q: It would be awesome if you could generate <INSERT ITEM HERE>. Can you add
   it to the Fake Name Generator?
A: Maybe. Send an email to Jacob@FakeNameGenerator.com and I'll see what I can
   do.
   
Q: Can I use these credit card numbers to buy stuff online?
A: No. Its the FAKE name generator, not the real-stolen-credit-card generator.
   All the included credit card numbers are completely fake.

Q: The zip codes and/or credit card numbers and/or social security numbers
   aren't showing up correctly in Excel. How do I fix this?
A: Change the column type to text. This will prevent Excel from formatting the
   numbers into scientific notation and/or stripping leading zeroes.
